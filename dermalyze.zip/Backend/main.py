# # import torch
# # import torch.nn as nn
# # from fastapi import FastAPI, UploadFile, File
# # from fastapi.middleware.cors import CORSMiddleware
# # from torchvision import models, transforms
# # from PIL import Image
# # import io

# # app = FastAPI(title="Dermalyze Skin Disease Classification")

# # # --- STEP 1: Enable CORS (To connect with Frontend) ---
# # app.add_middleware(
# #     CORSMiddleware,
# #     allow_origins=["*"],  # Allows all origins, change this to your frontend URL later
# #     allow_credentials=True,
# #     allow_methods=["*"],
# #     allow_headers=["*"],
# # )

# # # --- STEP 2: Define Model Structure (ResNet50) ---
# # def get_model():
# #     # Using weights=None to avoid warnings in newer Torch versions
# #     model = models.resnet50(weights=None)
# #     num_ftrs = model.fc.in_features
# #     # Matching the 8 classes you trained in Colab
# #     model.fc = nn.Linear(num_ftrs, 8)
# #     return model

# # # --- STEP 3: Load Model and Weights ---
# # device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# # model = get_model()

# # try:
# #     # Loading the checkpoint dictionary
# #     checkpoint = torch.load("best_model.pt", map_location=device)
    
# #     # Extracting only the model weights from the dictionary
# #     if isinstance(checkpoint, dict) and "model" in checkpoint:
# #         model.load_state_dict(checkpoint["model"])
# #         print("Success: Model weights loaded from dictionary.")
# #     else:
# #         model.load_state_dict(checkpoint)
# #         print("Success: Model weights loaded directly.")
# # except Exception as e:
# #     print(f"Error loading model: {e}")

# # model.to(device)
# # model.eval()

# # # --- STEP 4: Class Names (Must be in the same order as training) ---
# # class_names = [
# #     'BA- cellulitis', 
# #     'BA-impetigo', 
# #     'FU-athlete-foot', 
# #     'FU-nail-fungus', 
# #     'FU-ringworm', 
# #     'PA-cutaneous-larva-migrans', 
# #     'VI-chickenpox', 
# #     'VI-shingles'
# # ]

# # # --- STEP 5: Image Pre-processing ---
# # preprocess = transforms.Compose([
# #     transforms.Resize(256),
# #     transforms.CenterCrop(224),
# #     transforms.ToTensor(),
# #     transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
# # ])

# # # --- STEP 6: API Endpoints ---
# # @app.get("/")
# # def home():
# #     return {"status": "Dermalyze Backend is Active", "classes": len(class_names)}

# # @app.post("/predict")
# # async def predict(file: UploadFile = File(...)):
# #     try:
# #         # Read uploaded image
# #         contents = await file.read()
# #         image = Image.open(io.BytesIO(contents)).convert('RGB')
        
# #         # Transform image for ResNet50
# #         input_tensor = preprocess(image).unsqueeze(0).to(device)
        
# #         # Inference (Prediction)
# #         with torch.no_grad():
# #             outputs = model(input_tensor)
# #             probabilities = torch.nn.functional.softmax(outputs, dim=1)
# #             confidence, preds = torch.max(probabilities, 1)

# #         return {
# #             "success": True,
# #             "prediction": class_names[preds[0]],
# #             "confidence": f"{round(confidence.item() * 100, 2)}%",
# #             "all_probabilities": {
# #                 class_names[i]: f"{round(prob.item() * 100, 2)}%" 
# #                 for i, prob in enumerate(probabilities[0])
# #             }
# #         }
# #     except Exception as e:
# #         return {"success": False, "error": str(e)}

# # # To run: uvicorn main:app --reload






# import torch
# import torch.nn as nn
# from fastapi import FastAPI, UploadFile, File
# from fastapi.middleware.cors import CORSMiddleware
# from torchvision import models, transforms
# from PIL import Image
# import io

# app = FastAPI(title="Dermalyze Skin Disease Classification")

# # --- STEP 1: Enable CORS (Important for Localhost connection) ---
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["http://localhost:3000", "*"],  # Allows React dev server
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

# # --- STEP 2: Define Model Structure (ResNet50) ---
# def get_model():
#     model = models.resnet50(weights=None)
#     num_ftrs = model.fc.in_features
#     # Ensure this matches your saved checkpoint's output size
#     model.fc = nn.Linear(num_ftrs, 8) 
#     return model

# # --- STEP 3: Load Model and Weights ---
# device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# model = get_model()

# try:
#     # Loading checkpoint dictionary
#     checkpoint = torch.load("best_model.pt", map_location=device)
    
#     if isinstance(checkpoint, dict) and "model" in checkpoint:
#         model.load_state_dict(checkpoint["model"])
#         print("Success: Model weights loaded from dictionary.")
#     else:
#         model.load_state_dict(checkpoint)
#         print("Success: Model weights loaded directly.")
# except Exception as e:
#     print(f"Error loading model: {e}")

# model.to(device)
# model.eval()

# # --- STEP 4: Class Names ---
# class_names = [
#     'BA- cellulitis', 
#     'BA- impetigo', 
#     'FU-athlete-foot', 
#     'FU-nail-fungus', 
#     'FU-ringworm', 
#     'PA-cutaneous-larva-migrans', 
#     'VI-chickenpox', 
#     'VI-shingles'
# ]

# # --- STEP 5: Image Pre-processing ---
# preprocess = transforms.Compose([
#     transforms.Resize(256),
#     transforms.CenterCrop(224),
#     transforms.ToTensor(),
#     transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
# ])

# # --- STEP 6: API Endpoints ---
# @app.get("/")
# def home():
#     return {"status": "Dermalyze Backend is Active", "classes": len(class_names)}

# @app.post("/predict")
# async def predict(file: UploadFile = File(...)):
#     try:
#         # Read and validate image
#         contents = await file.read()
#         image = Image.open(io.BytesIO(contents)).convert('RGB')
        
#         # Transform image for ResNet50
#         input_tensor = preprocess(image).unsqueeze(0).to(device)
        
#         # Inference (Prediction)
#         with torch.no_grad():
#             outputs = model(input_tensor)
#             probabilities = torch.nn.functional.softmax(outputs, dim=1)
#             confidence, preds = torch.max(probabilities, 1)

#         # Return formatted JSON
#         return {
#             "success": True,
#             "prediction": class_names[preds[0]],  # e.g., 'BA- cellulitis'
#             "confidence": f"{round(confidence.item() * 100, 2)}%",
#             "all_probabilities": {
#                 class_names[i]: f"{round(prob.item() * 100, 2)}%" 
#                 for i, prob in enumerate(probabilities[0])
#             }
#         }
#     except Exception as e:
#         # Return error in JSON format so frontend can show alert
#         return {"success": False, "error": str(e)}

# # To run: uvicorn main:app --reload --host 127.0.0.1 --port 8000







import torch
import torch.nn as nn
import os
from fastapi import FastAPI, UploadFile, File, Form # 'Form' add kiya
from fastapi.middleware.cors import CORSMiddleware
from torchvision import models, transforms
from PIL import Image
import io
from dotenv import load_dotenv
from openai import OpenAI

# --- Load Environment Variables ---
load_dotenv()

app = FastAPI(title="Dermalyze Skin Disease Classification")

# --- STEP 1: Enable CORS ---
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- STEP 2: Initialize OpenAI Client ---
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# --- STEP 3: Define Model Structure (ResNet50) ---
def get_model():
    model = models.resnet50(weights=None)
    num_ftrs = model.fc.in_features
    model.fc = nn.Linear(num_ftrs, 8) 
    return model

# --- STEP 4: Load Model and Weights ---
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = get_model()

try:
    checkpoint = torch.load("best_model.pt", map_location=device)
    if isinstance(checkpoint, dict) and "model" in checkpoint:
        model.load_state_dict(checkpoint["model"])
    else:
        model.load_state_dict(checkpoint)
    print("Success: Model weights loaded.")
except Exception as e:
    print(f"Error loading model: {e}")

model.to(device)
model.eval()

# --- STEP 5: Class Names ---
class_names = [
    'BA- cellulitis', 
    'BA- impetigo', 
    'FU-athlete-foot', 
    'FU-nail-fungus', 
    'FU-ringworm', 
    'PA-cutaneous-larva-migrans', 
    'VI-chickenpox', 
    'VI-shingles'
]

# --- STEP 6: Image Pre-processing ---
preprocess = transforms.Compose([
    transforms.Resize(256),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

# --- UPDATED FUNCTION: Call OpenAI API ---
def get_ai_recommendations(disease_name: str, user_symptoms: str = ""):
    try:
        system_prompt = """
        You are a professional and empathetic dermatology assistant. 
        Your goal is to provide general, safe, and actionable advice based on the skin condition detected.
        Structure your response in clear bullet points. 
        Always include a strong disclaimer that this is AI-generated information and not a substitute for a professional doctor.
        """

        # Yahan hum symptoms ko bhi prompt mein dal rahe hain
        user_prompt = f"""
        The AI model has detected the skin condition: '{disease_name}'.
        
        The user has reported the following symptoms: "{user_symptoms}".
        
        Please provide a response covering the following:
        1. **Brief Overview**: What this condition is in simple terms.
        2. **Home Remedies**: 3-4 bullet points on natural care relevant to these symptoms.
        3. **Over-the-Counter Solutions**: Suggested creams or medicines (general names).
        4. **Red Flags**: When to see a doctor immediately, especially considering the user's description.
        
        Keep the tone helpful and concise. Format with bold headings.
        """

        response = client.chat.completions.create(
            model="gpt-3.5-turbo", 
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            temperature=0.7
        )
        
        return response.choices[0].message.content
        
    except Exception as e:
        print(f"OpenAI API Error: {e}")
        return "Could not fetch recommendations from AI at this moment. Please consult a dermatologist."

# --- STEP 7: API Endpoints ---
@app.get("/")
def home():
    return {"status": "Dermalyze Backend is Active", "classes": len(class_names)}

@app.post("/predict")
async def predict(file: UploadFile = File(...), symptoms: str = Form("")): # 'symptoms' add kiya
    try:
        # 1. Image Processing & Model Prediction
        contents = await file.read()
        image = Image.open(io.BytesIO(contents)).convert('RGB')
        input_tensor = preprocess(image).unsqueeze(0).to(device)
        
        with torch.no_grad():
            outputs = model(input_tensor)
            probabilities = torch.nn.functional.softmax(outputs, dim=1)
            confidence, preds = torch.max(probabilities, 1)

        predicted_disease = class_names[preds[0]]

        # 2. Call OpenAI with disease and symptoms
        recommendations = get_ai_recommendations(predicted_disease, symptoms)

        # 3. Return Combined Result
        return {
            "success": True,
            "prediction": predicted_disease,
            "confidence": f"{round(confidence.item() * 100, 2)}%",
            "recommendations": recommendations,
            "all_probabilities": {
                class_names[i]: f"{round(prob.item() * 100, 2)}%" 
                for i, prob in enumerate(probabilities[0])
            }
        }
    except Exception as e:
        return {"success": False, "error": str(e)}

# To run: uvicorn main:app --reload --host 127.0.0.1 --port 8000